
#include "main.h"

//--------------------------------------------------------------------------------------------------------//

//python add command to raft
//ido - add new queue event and start commit process
void add_new_value(int commit_id,char * key, char * value);


//pyhton start raft process, call init_raft() [difficulte = 2 ]
int run_raft(char* raft_ip,int raft_port,int id,int members_num,int leader_timeout)
{
    pthread_t server_thread,timeout_thread,raft_handler_thread;
    if(init_raft(raft_ip,raft_port,id,members_num,leader_timeout))
    {
        what do do here?
    }

    pthread_create(&raft_handler_thread, NULL, raft_manager, NULL);
    pthread_create(&server_thread, NULL, run_multicast_listener, NULL);
    pthread_create(&timeout_thread, NULL, create_timeout_event, NULL);

    pthread_join(raft_handler_thread, NULL);
    pthread_join(server_thread, NULL);
    pthread_join(timeout_thread, NULL);
    return 0;
}


//c calls py func
//itay - set the callback function in the shared_raft_data struct
int transfer_callback_function(void (*add_to_log_DB)(int log_id,char* cmd,char* key,char* value),void (*update_DB)(enum DB_type DB_flag,char * key,char* value),
                               void (*get_log_by_diff)(int from,int to), void write_to_logger(char * file_name,int line))
{
    sharedRaftData.python_functions.add_to_log_DB  =    add_to_log_DB;
    sharedRaftData.python_functions.update_DB =         update_DB;
    sharedRaftData.python_functions.get_log_by_diff =   get_log_by_diff;

//how to transfare python func that get a few args ??????????????????
sharedRaftData->python_functions->write_to_logger = write_to_logger;
//??????????????????????????????????????????????
}


//close raft server
void exit_handler(int sig){
    printf("some massage ?????/\n");
    exit(0);
}


int init_sig_handler(){
    //handler for raft timeout event
    struct sigaction sa_timeout;
    //handler for exit command from CLI
    struct sigaction sa_exit;
    memset(&sa_timeout, 0, sizeof (sa_timeout));
    memset(&sa_exit, 0, sizeof (sa_exit));
    sa_timeout.sa_handler = &time_out_hendler;
    sa_timeout.sa_handler = &exit_handler;
    return sigaction(SIGALRM, &sa_timeout, NULL) | sigaction(SIGSTOP, &sa_timeout, NULL);
}

int init_raft_sync(){
    return pthread_mutex_init(&sharedRaftData->raft_sync->mutex,NULL) | sem_init(&sharedRaftData->raft_sync->sem,0,0);
}


State (*do_nothing)(Queue_node_data *node){
    return sharedRaftData->raft_state->current_state;
}


//initialize parameters (socket etc)
//itay [difficulte = 1 ]
int init_raft(char* raft_ip,int raft_port,int id,int members_num,int leader_timeout,void(*set_callback_function)(void)){
    state_server_config server_config;
    configuration raft_configuration;
    python_function python_functions;
    threads_sync raft_sync;
    State (*handlers_functions_arr[STATE_MAX_SIZE][EVENT_MAX_SIZE])(nude_queue *);
    shared_raft_data raft_data_memory;
    init_raft_memory(&raft_data_memory,&server_config,sharedRaftData.Raft_queue.queue,&raft_configuration,&python_functions,&raft_sync);
    init_state_functions_handler(functionArr);
    if(set_raft_data(char* raft_ip,int raft_port,int id,int members_num,int leader_timeout,set_callback_function)){

    }
    if(init_raft_server(sharedRaftData->server_config)){

    }
    if(init_sig_handler()){

    }
    if(init_raft_sync()){

    }
    if(init_handlers_functions()){

    }
    //for rand func
    srand((unsigned) time(&t));
    return 0;
}

int calculate_raft_rand_timeout(){
    return MIN_RAFT_TIMEOUT + rand()%(MAX_RAFT_TIMEOUT-MIN_RAFT_TIMEOUT);
}

//itay
int set_raft_data(char* raft_ip,int raft_port,int id,int members_num,int leader_timeout,void(*set_callback_function)(void)){
    //set sharedRaftData->python_functions
    //call to python function that call to transfer_callback_function and set the function pointer
    set_callback_function();

    //set sharedRaftData->server_config
    sharedRaftData->server_config->multy_cast_ip       = raft_ip;
    sharedRaftData->server_config->port                = raft_port;

    //set sharedRaftData->raft_state
    memset(&sharedRaftData->raft_state,0,sizeof(state));
    sharedRaftData->raft_state->current_state          = FOLLOWER;
    sharedRaftData->raft_state->id                     = id;
    sharedRaftData->raft_state->member_num             = member_num;
    sharedRaftData->raft_state->timeout                = calculate_raft_rand_timeout();

    //set sharedRaftData->raft_configuration
    sharedRaftData->raft_configuration->leader_timeout = leader_timeout;

    //set sharedRaftData->raft_queue
    sharedRaftData->raft_queue                         = what to do here?

}


//malloc for quque , state, handlers, etc
//itay [difficulte = 1 ]

int free_memory(void ** memory){
    while(*memory != EOF){
        if(*memory){
            free(memory);
        }
        memory++;
    }
    return 0;
}


int validate_memory(void ** memory){
    void ** memory_pnt = memory;
    while(*memory_pnt != EOF){
        if(!*memory_pnt){
            return !free_memory(memory);
        }
        memory_pnt++;
    }
    return 0;
}


void init_raft_memory(shared_raft_data * raft_data_memory,state_server_config *server_config,queue *raft_queue,configuration *raft_configuration,
                      python_function *python_functions,threads_sync *raft_sync){
    raft_data_memory->raft_queue         = raft_queue;
    raft_data_memory->server_config      = server_config;
    raft_data_memory->raft_configuration = raft_configuration;
    raft_data_memory->raft_state         = raft_state;
    raft_data_memory->python_functions   = python_functions;
    raft_data_memory->raft_sync          = raft_sync;
    sharedRaftData                            = raft_data_memory;

}


//itay(oren) [difficulte = 2 ]
int init_raft_server(state_server_config *server_config);

//itay(oren) - read data from socket [difficulte = 3 ]
char* read_from_multy_socket(int socket_fd);

//itay(oren) - send data by socket [difficulte = 2 ]
int send_raft_message(char * message);

//create new_queue with key val for commit proc
void create_new_log_command(int log_id,char * cmd,char * key, char * value,Queue_node_data * res){
    what to do here?
}

void start_commit_proccess(int log_id,char * cmd,char * key, char * value){
    Queue_node_data new_node = NULL;
    create_new_log_command(log_id,cmd,key,value,&new_node);
    if(new_node){
        push_queue(&new_node);
    }
}

//listen to multicast

// in while(1):
//dequeue and
// parse message
//call event function in state machine


//oren(itay) - while(1) , raft_listenter -> add_to_queue [difficulte = 2 ]
void run_multicast_listener(void * args){
    Queue_node_data new_node;
    int is_valid;
    while(1){
        is_valid = read_from_multicast_socket(sharedRaftData.server_config.multy_cast_fd,&new_node);
        if(is_valid && is_relevant_message(&new_node)){
            push_queue(&new_node);
        }
    }
}

//oren(ido) . according to shany doc [difficulte = 3 ]
char * create_new_massage(state * raft_state);

/////////////////////////////////


//oren(itay) SIGARAM - add new timeout event to queue [difficulte = 1 ]
void create_timeout_event(void * args){
    struct itimerval timer;
    memset(&timer,0,sizeof(struct itimerval));
    while(1){
        timer.it_value.tv_usec = sharedRaftData->raft_state->timeout * MILISEC_CONVERT /*1000 for milliseconds*/;
        setitimer(ITIMER_REAL, &timer, NULL);
    }
}


void time_out_hendler(int sig){
    //calloc set everything to 0
    Queue_node_data new_node;
    new_node.event  = TIMEOUT;
    push_queue(&new_node);

}

char * get_current_state_value(State current_state){
    return states_name[current_state];
}

void update_state_raft_DB(State old_state, State new_state){
    if(old_state != new_state){
        sharedRaftData->python_functions->update_DB(STATE_DB,CURRENT_STATE_KEY,get_current_state_value(new_state));
    }
}


//oren(itay) - wait to sem -> get message from queue -> change state -> run handler->change_current_state-> (call to oren state code) [difficulte = 2 ]
void raft_manager(void * args){
    Queue_node_data new_node;
    while(1){
        sem_wait(&sharedRaftData.Raft_queue.sem_queue);
        pop_queue(&new_node);
        operate_machine_state(&new_node);
    }
}



//--------------------------------------------------------------------------------------------------------//


void write_to_log(int level_msg,int message_type,const char *format, ...);






