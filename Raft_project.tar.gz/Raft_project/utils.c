//
// Created by ubuntu on 25/02/18.
//

#include "utils.h"

//shany [difficulte = 3 ]
int is_relevant_message(Queue_node_data * node_message)
{
    int event_bits[3][10];

    //FOLLOWER arr
    event_bits[FOLLOWER] = {1,1,1,0,0,1,1,0,1,0};
    //CANDIDATE arr
    event_bits[CANDIDATE] = {1,1,0,0,0,0,0,1,0,0};
    //LEADER arr
    event_bits[LEADER] = {1,1,0,0,1,0,0,0,1,1};

    int is_relevant = event_bits[sharedRaftData.raft_state.current_state][node_message->event];

    //special cases
    /*
    if(my_state.current_state == FOLLOWER)
    {
        return is_relevant_for_follower(node_message) && is_relevant ;
    }


    else */
    if(sharedRaftData.raft_state.current_state == CANDIDATE)
    {
        return is_relevant_for_candidate(node_message) && is_relevant;
    }


    else if(sharedRaftData.raft_state.current_state == LEADER)
    {
        return is_relevant_for_leader(node_message) && is_relevant;
    }

    return is_relevant;

};

int is_relevant_for_candidate(Queue_node_data * node_message)
{
    if(node_message->term < sharedRaftData.raft_state.term ||
            ((node_message->event == VOTE) &&(node_message->message_sent_to != sharedRaftData.raft_state.server_id)))
    {
        return 0;
    }
    return 1;
}


int is_relevant_for_leader(Queue_node_data * node_message)
{
    if( ((node_message->event == KEEP_ALIVE_HB)&&(sharedRaftData.raft_state.term > node_message->term))
        || ((node_message->event == SYNC_RES) && (node_message->message_sent_to != sharedRaftData.raft_state.server_id)))
    {
        return 0;
    }
    return 1;
}
