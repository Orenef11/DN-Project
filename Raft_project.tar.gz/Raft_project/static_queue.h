
#ifndef RAFT_PROJECT_STATIC_QUEUE_H
#define RAFT_PROJECT_STATIC_QUEUE_H

#include "general.h"

void init_raft_queue();

void push_queue(Queue_node_data *data);

void pop_queue(Queue_node_data *ret);

void clear_queue();


#endif //RAFT_PROJECT_STATIC_QUEUE_H
