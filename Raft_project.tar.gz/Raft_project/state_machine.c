#include "state_machine.h"

const char* statesName[] = {"FOLLOWER", "CANDIDATE", "LEADER"};

void operate_machine_state(Queue_node_data * node){
    handlers_functions_arr[sharedRaftData.raft_state.current_state][node->event](node);
}

void initState(State *state, StateFunctions *functionsArr[3]){
    state->statesName = FOLLOWER;
    for(int i=0; i < 3; i++){
        state->functionsArr[i] = functionsArr[i];
    }

}
void destoryState(State *state){
    for(int i = 0; i < 3; i++) {
        free(state->functionsArr[i]);
    }
    free(state);
}
void stateToString(State *state){
    printf("State %s\n", statesName[state->statesName]);

}

void do_nothing(Queue_node_data * node){
    write_to_looger();
}


void init_state_functions_handler(State (*handlers_functions_arr[STATE_MAX_SIZE][EVENT_MAX_SIZE])(Queue_node_data *))
{
    //init follower functions
    handlers_functions_arr[FOLLOWER][TIMEOUT] = follower_time_out_handler;
    handlers_functions_arr[FOLLOWER][KEEP_ALIVE_HB] = follower_hb_keep_alive_handler;
    handlers_functions_arr[FOLLOWER][SET_LOG_HB] = follower_hb_set_log_handler;
    handlers_functions_arr[FOLLOWER][SET_LOG_RES] = NULL;
    handlers_functions_arr[FOLLOWER][SYNC_REQ] = NULL;
    handlers_functions_arr[FOLLOWER][SYNC_RES] = follower_sync_res_handler;
    handlers_functions_arr[FOLLOWER][COMMIT_OK] = follower_commit_ok_handler;
    handlers_functions_arr[FOLLOWER][VOTE] = NULL;
    handlers_functions_arr[FOLLOWER][REQUEST_FOR_VOTE] = follower_vote_req_handler;
    handlers_functions_arr[FOLLOWER][PY_SEND_LOG] = NULL;

    handlers_functions_arr[CANDIDATE][TIMEOUT] = candidte_time_out_handler;
    handlers_functions_arr[CANDIDATE][KEEP_ALIVE_HB] = cadidate_keep_alive_hb_handler;
    handlers_functions_arr[CANDIDATE][SET_LOG_HB] = NULL;
    handlers_functions_arr[CANDIDATE][SET_LOG_RES] = NULL;
    handlers_functions_arr[CANDIDATE][SYNC_REQ] = NULL;
    handlers_functions_arr[CANDIDATE][SYNC_RES] = NULL;
    handlers_functions_arr[CANDIDATE][COMMIT_OK] = NULL;
    handlers_functions_arr[CANDIDATE][VOTE] = NULL;
    handlers_functions_arr[CANDIDATE][REQUEST_FOR_VOTE] = candidate_vote_for_me_handler;
    handlers_functions_arr[CANDIDATE][PY_SEND_LOG] = NULL;

    handlers_functions_arr[LEADER][TIMEOUT] = leader_time_out_handler;
    handlers_functions_arr[LEADER][KEEP_ALIVE_HB] = leader_hb_handler;
    handlers_functions_arr[LEADER][SET_LOG_HB] = NULL;
    handlers_functions_arr[LEADER][SET_LOG_RES] = leader_log_res_handler;
    handlers_functions_arr[LEADER][SYNC_REQ] = leader_sync_req_handler;
    handlers_functions_arr[LEADER][SYNC_RES] = NULL;
    handlers_functions_arr[LEADER][COMMIT_OK] = NULL;
    handlers_functions_arr[LEADER][VOTE] = leader_vote_handler;
    handlers_functions_arr[LEADER][REQUEST_FOR_VOTE] = NULL; //do nothing
    handlers_functions_arr[LEADER][PY_SEND_LOG] = leader_send_log_hb_handler;

}

