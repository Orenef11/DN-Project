#ifndef RAFT_PROJECT_MAIN_H
#define RAFT_PROJECT_MAIN_H

#include "utils.h"
#include "state_machine.h"
#include "static_queue.h"
#include "raft_server.h"

#endif //RAFT_PROJECT_MAIN_H