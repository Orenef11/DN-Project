#include "follower_handlers.h"

//TBD- names of DBS in python functions,

enum stateType follower_hb_set_log_handler(queue_node* node)
{
    char * new_message;
    enum eventType event;

    my_state.wakeup_counter = 0;

    //compare leaders term to my term
    if(node->term == my_state.term)
    {
        //I dont need an updated
        if(my_state.last_commit_index+1 == node->to_be_commited_index)
        {

            sharedRaftData.python_functions->add_to_log_DB(node->to_be_commited_index,node->command_log,node->key,node->value)
            update_DB(CURRENT_STATE_DB,"last applied",node->to_be_commited_index);
            my_state.last_log_index = my_state.last_commit_index+1;

            //send set log res to leader
            event = SET_LOG_RES;
            new_message = create_new_massage(event, node);
            send_raft_message(new_message, sizeof(new_message));//TBD - check returned value
        }

            //I need an update
        else
        {
            //send an update request to the leader
            event = SYNC_REQ;
            new_message = create_new_massage(event, node);
            send_raft_message(new_message);
        }
    }

    else if(node->term > my_state.term)
    {
        //TBD - what should happen here?
        my_state.term == node->term;
    }

    return FOLLOWER;
};



enum stateType follower_commit_ok_handler(queue_node* node)
{
    char * new_message;
    enum eventType event;

    my_state.wakeup_counter = 0;

    if(node->term == my_state.term)
    {
        update_DB(KEY_VAL_DB,node->key,node->value);
        update_DB(CURRENT_STATE_DB,"last_commited",node->to_be_commited_index);
        my_state.last_commit_index = my_state.last_log_index; //same as my_state.last_commit_index++
    }

    return FOLLOWER;
}




enum stateType follower_sync_res_handler(queue_node* node)
{

    my_state.wakeup_counter = 0;

    if (my_state.server_id == node->message_send_to)
    {

        char* line = strtok(node.)







        my_state.last_commit_index = node->last_log_index;
    }

    return FOLLOWER;
};




enum stateType follower_vote_req_handler(queue_node* node)
{
    my_state.wakeup_counter = 0;

    if(my_state.did_I_vote == "n")//I didnt vote
    {

        if(node->term > my_state.term)
        {
            char * new_message;
            enum eventType event = VOTE;
            my_state.term++;
            my_state.did_I_vote = "y";
            //TBD - the term shouldnt be in the current state db?
            update_DB(CURRENT_STATE_DB,"term",node->term);

            new_message = create_new_massage(event,node);
            send_raft_message(new_message);

        }
        // else ignore
    }
    // else ignore

    return FOLLOWER;
}




enum stateType follower_hb_keep_alive_handler(queue_node* node)
{
    enum eventType event = KEEP_ALIVE_HB;
    my_state.wakeup_counter=0;

    if(node->term > my_state.term)
    {
        my_state.term = node->term;
        //TBD - check if need to request an update?
        return FOLLOWER;

    }
}



state follower_time_out(node_queue * node)
{
    if(++sharedRaftData->raft_state->wakeup_counter == 2 ){
        sharedRaftData->raft_state->vote_counter=1;
        return CANDIDATE;
    }
    return FOLLOWER;
}


