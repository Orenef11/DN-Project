//
// Created by ubuntu on 25/02/18.
//

#ifndef RAFT_PROJECT_UTILS_H
#define RAFT_PROJECT_UTILS_H

#include "general.h"

int is_relevant_message(Queue_node_data * node_message);

#endif //RAFT_PROJECT_UTILS_H
