#ifndef RAFT_PROJECT_STATE_MACHINE_H
#define RAFT_PROJECT_STATE_MACHINE_H

#include <stdio.h>
#include <malloc.h>

#include "candidate_handlers.h"
#include "follower_handlers.h"
#include "leader_handlers.h"


#define STATE_MAX_SIZE 3
#define EVENT_MAX_SIZE 9


typedef  enum states{FOLLOWER=0, CANDIDATE, LEADER, NOTCHANGE} States;

extern  const char* statesName[];


typedef struct stateFunctions{
    States (*functionArr[2])(void);
}StateFunctions;


typedef struct state{
    StateFunctions *functionsArr[3];
    States statesName;
}State;

//--------------------------------------------------------------------------------------------------------//

void operate_machine_state(Queue_node_data * node);
void initState(State *state, StateFunctions *functionsArr[3]);
void destoryState(State *state);
void stateToString(State *state);

void init_state_functions_handler(State (*handlers_functions_arr[STATE_MAX_SIZE][EVENT_MAX_SIZE])(Queue_node_data *));


State (*handlers_functions_arr[STATE_MAX_SIZE][EVENT_MAX_SIZE])(Queue_node_data *);//handlers for each state

#endif //RAFT_PROJECT_STATE_MACHINE_H
