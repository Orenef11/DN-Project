
#ifndef RAFT_PROJECT_FOLLOWER_HANDLERS_H
#define RAFT_PROJECT_FOLLOWER_HANDLERS_H

#include "general.h"

enum stateType follower_hb_set_log_handler(queue_node* node);

enum stateType follower_commit_ok_handler(queue_node* node);

enum stateType follower_sync_res_handler(queue_node* node);

enum stateType follower_vote_req_handler(queue_node* node);

enum stateType follower_hb_keep_alive_handler(queue_node* node);

enum stateType follower_time_out_handler(queue_node* node);


#endif //RAFT_PROJECT_FOLLOWER_HANDLERS_H
