
#include "candidate_handlers.h"

///candidate:

//itay relevant fileds from Node_queue - byte term [difficulte = 1 ]
enum stateType candidate_vote_for_me_handler(node_queue * node)
{
    //write log message (CANDIDATE_VOTE_FOR_ME_FORMAT="cd" becouse term is char and server_id is int)
    sharedRaftData->python_functions->write_to_logger(__FILE__,__LINE__,DEBUG_LEVEL,CANDIDATE_VOTE_FOR_ME,CANDIDATE_VOTE_FOR_ME_FORMAT,node->term,node->server_id);
    //increase vote_counter and check majurity
    if(++sharedRaftData->raft_state->vote_counter > sharedRaftData->raft_state->member_num/2+1){
        //change timeout for leader
        sharedRaftData->raft_state->timeout = sharedRaftData->raft_configuration->leader_timeout;
        //update DAL
        sharedRaftData->python_functions->update_DB(STATE_DB,CURRENT_STATE_KEY,LEADER_STATE_VALUE);
        //remove unrelevant queue element (any time when state will change )
        clear_queue(sharedRaftData->raft_queue);
        //change state to leader
        return LEADER;
    }
    //stay in the same state
    return CANDIDATE;
}


//ido byte term [difficulte = 1 ]
enum stateType cadidate_keep_alive_hb_handler(node_queue * node)
{

};


//shany relevant fileds from state term [difficulte = 1 ]
enum stateType candidte_time_out_handler(queue_node* node)
{
    char * new_message;
    enum eventType event = REQUEST_FOR_VOTE;

    my_state.term++;
    my_state.vote_counter =1;
    my_state.did_I_vote = "y";

    //TBD - ask ido about the message
    new_message = create_new_massage(event,node);
    send_raft_message(new_message);

    //TBD- what about the timer? CLEARE QUEUE?

    return CANDIDATE;
}