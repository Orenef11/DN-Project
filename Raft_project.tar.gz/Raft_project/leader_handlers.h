
#ifndef RAFT_PROJECT_LEADER_HANDLERS_H
#define RAFT_PROJECT_LEADER_HANDLERS_H

#include "general.h"

enum stateType leader_sync_req_handler(queue_node* node);

enum stateType leader_vote_handler(queue_node* node);

enum stateType leader_time_out_handler(queue_node* node);

enum stateType leader_hb_handler(queue_node* node);

enum stateType leader_send_log_hb_handler(queue_node* node);

enum stateType leader_log_res_handler(queue_node* node);


#endif //RAFT_PROJECT_LEADER_HANDLERS_H
