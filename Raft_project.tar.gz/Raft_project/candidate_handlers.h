
#ifndef RAFT_PROJECT_CANDIDATE_HANDLERS_H
#define RAFT_PROJECT_CANDIDATE_HANDLERS_H

#include "general.h"

enum stateType candidate_vote_for_me_handler(node_queue * node);

enum stateType cadidate_keep_alive_hb_handler(node_queue * node);

enum stateType candidte_time_out_handler(queue_node* node);


#endif //RAFT_PROJECT_CANDIDATE_HANDLERS_H
