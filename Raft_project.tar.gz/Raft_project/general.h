
#ifndef RAFT_PROJECT_GENERAL_H
#define RAFT_PROJECT_GENERAL_H


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <bits/signum.h>
#include <signal.h>


//define

//#define LEADER
//#define CANDIDATE
//#define FOLLOWER
//states



//log levels
#define DEBUG_LEVEL
#define INFO_LEVEL
#define WARN_LEVEL
#define ERROR_LEVEL
#define FATAL_LEVEL

//message type for log
#define CANDIDATE_VOTE_FOR_ME
//message format for log
#define CANDIDATE_VOTE_FOR_ME_FORMAT "cd"

#define CURRENT_STATE_KEY "currentState"
#define LEADER_STATE_VALUE "leader"

#define MAX_RAFT_TIMEOUT 150
#define MIN_RAFT_TIMEOUT 300
#define QUEUE_SIZE       555
#define MAX_CMD_SIZE     10
#define MAX_KEY_SIZE     50
#define MAX_VALUE_SIZE   50


//--------------------------------------------------------------------------------------------//


enum eventType {TIMEOUT, KEEP_ALIVE_HB, SET_LOG_HB, SET_LOG_RES, SYNC_REQ, SYNC_RES, COMMIT_OK, VOTE, REQUEST_FOR_VOTE,PY_SEND_LOG};
enum stateType {FOLLOWER,CANDIDATE,LEADER};
enum DB_type {DICT_DB,CONFIG_DB,CURRENT_STAT_DB};

typedef struct State{
    char term;
    int last_log_index;
    int last_commit_index;
    char current_state; //F/C/L //TBD- why not enum?????
    int members_amount;
    int server_id;

    //for candidate use
    int vote_counter;

    //for leader use
    int commit_counter;

    //for follower use
    char did_I_vote;

    int timeout;
    //if wakeup_counter == 2 , follower -> candidate
    int wakeup_counter;

    //all 9 options
    enum enentType event_type;
    //not nedded for now
    //State (*hendler)();
}state;


typedef struct State_server_config{
    int multy_cast_fd;
    char * multy_cast_ip;
    int port;
}state_server_config;


//
//typedef struct queue_node_data{
//    enum eventType event;
//    int term;
//    int start_log_index;
//    int last_log_index;
//    int to_be_commit_index;
//    int command_log;
//    char * key;
//    char * value;
//    int message_sent_by;
//    int message_send_to;
//    char* diffstr;
//}Queue_node_data;


typedef struct Keep_alive_hb{
    int to_be_commit_index;
    int last_log_id;
}keep_alive_hb;

typedef struct Set_log_hb{
    int commit_id;
    char cmd[MAX_CMD_SIZE];
    char key[MAX_KEY_SIZE];
    char value[MAX_VALUE_SIZE];

}set_log_hb;

typedef struct Sync_req{
    int follower_id;
    int start_log_index;
    int last_log_id;
}sync_req;

typedef struct Sync_res{
    int commit_id;
    char cmd[MAX_CMD_SIZE];
    char key[MAX_KEY_SIZE];
    char value[MAX_VALUE_SIZE];
}sync_res;

typedef struct Commit_ok{
    int last_log_index;
}commit_ok;

typedef struct Set_log_res{
    int to_be_commit_index;
}set_log_res;

typedef struct Vote{
    int message_sent_by;
}vote;

typedef struct Req_for_vote{
    int message_sent_by;
}req_for_vote;

typedef struct queue_node_data{
    enum eventType event;
    int term;
    int message_sent_by;
    int message_sent_to;
    union {
        keep_alive_hb keep_alive_hb_msg;
        set_log_hb  set_log_hb_msg;
        sync_req sync_req_msg;
        sync_res sync_res_msg;
        commit_ok commit_ok_msg;
        set_log_res set_log_res_msg;
        vote vote_msg;
        req_for_vote req_for_vote_msg;

    }msg_data;

}Queue_node_data;


typedef struct Configuration{
    int leader_timeout;
}configuration;


typedef struct Python_function{
    void (*add_to_log_DB)(int log_id,char* cmd,char* key,char* value);
    void (*update_DB)(int DB_flag,char * key,char* value);
    void (*get_log_by_diff)(int from,int to);
}python_function;


typedef struct Shared_raft_data{ //contains all the shared structures needed

    struct{
        Queue_node_data queue[QUEUE_SIZE];
        int queue_start;
        int queue_end;
        int queue_elements_amount;
        pthread_mutex_t mutex_queue;
        sem_t sem_queue;
    }Raft_queue;

    state_server_config server_config;//get from cli (server) - port,ip,multicast file descriptor
    state raft_state;//my state
    python_function python_functions;
    configuration raft_configuration;//raft configure - leader time out,
}shared_raft_data;



shared_raft_data sharedRaftData;

//--------------------------------------------------------------------------------------------------------//




#endif //RAFT_PROJECT_GENERAL_H
