#include "static_queue.h"

void init_raft_queue()
{
    sharedRaftData.Raft_queue.queue_start = 0;
    sharedRaftData.Raft_queue.queue_end = 0;
    sharedRaftData.Raft_queue.queue_elements_amount = 0;
    pthread_mutex_init(&sharedRaftData.Raft_queue.mutex_queue,NULL);
    sem_init(&sharedRaftData.Raft_queue.sem_queue,0,0); //sem is also a type of amount, so we need to init it back to 0 (when clearing queue)
}

void push_queue(Queue_node_data *data)
{
    if(sharedRaftData.Raft_queue.queue_elements_amount != QUEUE_SIZE -1)
    {
        pthread_mutex_lock(&sharedRaftData.Raft_queue.mutex_queue);

        memcpy(&sharedRaftData.Raft_queue.queue[sharedRaftData.Raft_queue.queue_end], data, sizeof(Queue_node_data));

        sharedRaftData.Raft_queue.queue_end = (sharedRaftData.Raft_queue.queue_end + 1) % QUEUE_SIZE;

        pthread_mutex_unlock(&sharedRaftData.Raft_queue.mutex_queue);
        sem_post(&sharedRaftData.Raft_queue.sem_queue);
    }
    else
    {
        write_to_logger();
    }
}


void pop_queue(Queue_node_data *ret)
{
    if(sharedRaftData.Raft_queue.queue_elements_amount != 0)
    {
        pthread_mutex_lock(&sharedRaftData.Raft_queue.mutex_queue);

        memcpy(ret, &sharedRaftData.Raft_queue.queue[sharedRaftData.Raft_queue.queue_start], sizeof(Queue_node_data));

        sharedRaftData.Raft_queue.queue_start = (sharedRaftData.Raft_queue.queue_start + 1) % QUEUE_SIZE;

        pthread_mutex_unlock(&sharedRaftData.Raft_queue.mutex_queue);
    }
    else
    {
        write_to_logger();
    }
}


void clear_queue()
{
    init_raft_queue();
}