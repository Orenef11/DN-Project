
#include "leader_handlers.h"

///leader:

//ido relevant fileds from Node_queue - byte term, last_log_id, sender_id [difficulte = 3 ]
enum stateType leader_sync_req_handler(queue_node* node)
{

};

//ido term [difficulte = 1 ]
enum stateType leader_vote_handler(queue_node* node)
{

};

//shany send hb message [difficulte = 2 ]
enum stateType leader_time_out_handler(queue_node* node)
{
    char * new_message;
    enum eventType event = TIMEOUT;

    new_message = create_new_massage(event, node);
    send_raft_message(new_message);//TBD - check returned value

    return LEADER;

}

//shany term [difficulte = 1 ]
enum stateType leader_hb_handler(queue_node* node)
{
    if(node->term > my_state.term)
    {
        //TBD - check how to operate idos func
        clear_queue();
        update_DB(CURRENT_STATE_DB,"status",FOLLOWER);
        //TBD- is there any other func to operate?
    }
    //else ignore

    return FOLLOWER;
}

//oren send_message->increase last_applied ->update_dal_last_applied [difficulte = 2 ]
enum stateType leader_send_log_hb_handler(queue_node* node)
{

};

//itay if majority -> update_dal_commit_id ->send_commit_ok ->send_signal_to_python (python update_dal_key-val_DB )
enum stateType leader_log_res_handler(queue_node* node)
{
    //check if he has the most votes and if he has, sends commit ok
};